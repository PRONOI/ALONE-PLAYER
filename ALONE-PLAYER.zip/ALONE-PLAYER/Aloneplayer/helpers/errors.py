class DurationLimitError(Exception):
    pass


class FFmpegReturnCodeError(Exception):
    pass
